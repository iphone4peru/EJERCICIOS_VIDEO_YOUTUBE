//
//  ViewController.swift
//  DemoSharedApp
//
//  Created by Fredy Asencios on 9/19/16.
//  Copyright © 2016 Academia moviles. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func llamame(sender: AnyObject) {
        
        let twit = "https://twitter.com/sharonstone"
        if let urlTwit = NSURL(string: twit) {
        
        UIApplication.sharedApplication().openURL(urlTwit)
        }
    }

}

